package com.company;
/*
    StandObject: inventory ()
    Stand Class: displayFruit()

    Data types: int, object(explicit casting....calling itself and all classes)
    Ex: Stand.inventory

    fruit data types: strings, floats, interger (preferable in monitary situations...1.05 written as 105)
    stand data types: int, object(explicit casting...calling itself and all classes)
 * Ex: Stand.inventory

 */
public class Stand {
   private Fruit[] inventory;

   public Stand(Fruit[] inv) {
       this.inventory = inv;

    }
}
