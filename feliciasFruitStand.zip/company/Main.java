package com.company;
/*
Create a new InteliJ project called "FeliciasFruitStand"

Objects
Create a Fruit class that can has properties for price, name, quantity available and quantity sold
Create a Stand class that has a property for inventory, purchase(update sold quantity), addInventory(update available Quantity)

Fruit Object: price, name, quantity, available and quantity sold
Fruit Class: Override(toString), purchase, addInventory

Create and stand class that has a property for inventory

    StandObject: inventory ()
    Stand Class: displayFruit()

Methods

The Fruit class should have an "Override" toString method that returns an output with all of a Fruits information

The Fruit class should also include methods called "purchase" & "addInventory" that update the available and sold quantity of the Fruit

The Stand class should have a method called displayFruit that prints the information of all Fruits available



*/
public class Main {

    public static void main(String[] args) {
    //Fruit(String name, int price, int qSold,  int qAvail)
         Fruit fruit1 = new Fruit("banana", 300, 80, 50);
         Fruit fruit2 = new Fruit("mango", 500, 100, 40);
         Fruit fruit3 = new Fruit("apple", 250, 150, 80);
         fruit1.addInventory(5);
        System.out.println( fruit1.getQuantAvailable());
        System.out.println( fruit2.getQuantAvailable());
        System.out.println( fruit3.getQuantAvailable());

        System.out.println(fruit1.toString());
        System.out.println(fruit2.toString());
        System.out.println(fruit3.toString());



    }
}
