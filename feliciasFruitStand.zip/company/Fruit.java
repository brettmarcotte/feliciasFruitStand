package com.company;

import java.text.NumberFormat;

/*      Fruit Object: price, name, quantity, available and quantity sold
        Fruit Class: Override(toString), purchase, addInventory

        Fruits: Mango, Apple, Oranges

        Data types: strings, floats, integer

*/
public class Fruit {

    private int price = 0;
    private String name = "";
    private int quantAvailable = 0;
    private int quantSold = 0;

    public Fruit(String name, int price, int qSold, int qAvail) {

        this.price = price;
        this.name = name;
        this.quantAvailable = qAvail;
        this.quantSold = qSold;
    }


    public void purchase(int value) {

        if(this.quantAvailable < value)

        this.quantSold -= value;
        this.quantAvailable -= value;

    }

    public void addInventory(int value) {

        quantAvailable += value;

    }

    public int getQuantAvailable(){
        return quantAvailable;
    }

    @Override
    public String toString() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();

        String outPut = "";
        outPut += "Name: " + name + "\n" + "Price: " + currency.format(price / 100) + "\n" + "Available Quantity: " + quantAvailable + "\n" + "Amount Sold: " + quantSold + "\n";
        return outPut;
    }



}
