package com.company;

import java.text.NumberFormat;

public class Fruit {

    public int price = 0;
    public String name = "";
    public int quantAvailable = 0;
    public int quantSold = 0;

    public Fruit(String name, int price, int qSold, int qAvail) {

        this.price = price;
        this.name = name;
        this.quantAvailable = qAvail;
        this.quantSold = qSold;

        Stand.fruitTypeArray.add(this);

    }
    public void purchase(int value) {

        if(this.quantAvailable < value);

        this.quantSold -= value;
        this.quantAvailable -= value;
        System.out.println("Thank you for your purchase");
    }

    public void refunded(int value) {

        this.quantSold -= value;
        this.quantAvailable += value;
        System.out.println("Your account has been refunded, please wait 3-5 business days");
    }


    public void subtractLosses(int value){
        quantAvailable -= value;
    }


    public void addInventory(int value) {
        quantAvailable += value;
    }

    public int getQuantAvailable() {
        return quantAvailable;
    }



    @Override
    public String toString() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();

        String outPut = "";
        outPut += "Name: " + name + "\n" + "Price: " + currency.format(price / 100) + "\n" + "Available Quantity: " + quantAvailable + "\n" + "Amount Sold: " + quantSold + "\n";
        return outPut;
    }

}
