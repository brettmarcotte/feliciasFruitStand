package com.company;

import java.util.ArrayList;

public class Stand {

    public int Count = 0;
    //this variable is an array of fruit objects
    public Fruit[] inventory;
    public static int Profit = 0;
    //beginning of array list
    public static ArrayList<Fruit> fruitTypeArray = new ArrayList<>();

    //This is a constructor - a constructor is a blueprint for an object
    public static void standProfit() {
        System.out.println("This stand turned a profit of " + Profit);
    }
    public static void getFruitType(String val) {

        System.out.println(fruitTypeArray);
    }
    public void displayFruit() {

        if (fruitTypeArray.isEmpty()) {
            System.out.println("Inventory is empty");
        } else if (fruitTypeArray.size() == 1) {
            System.out.println("The stand has " + fruitTypeArray.size() + "item is in inventory");
            System.out.println(fruitTypeArray);
        } else {
            System.out.println("The stand has " + fruitTypeArray.size() + "item is in inventory");

        }

    }
    public void checkInventory() {

        for(int i = 0; i < fruitTypeArray.size(); i++) {
           Count += fruitTypeArray.get(i).quantAvailable;
            System.out.println("The stand has " + Count + "items in inventory");

        }

    }
    public void wasteInventory() {
        for(int i = 0; i < fruitTypeArray.size(); i--) {
            Count -= fruitTypeArray.get(i).quantAvailable;
            System.out.println("The stand has " + Count + "items in the waste inventory");

        }
    }

}
