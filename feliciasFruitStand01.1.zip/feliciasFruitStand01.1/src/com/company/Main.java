package com.company;

public class Main {

    public static void main(String[] args) {
        Fruit fruit1 = new Fruit("orange", 200, 70, 60);
        Fruit fruit2 = new Fruit("pineapple", 600, 90, 50);
        Fruit fruit3 = new Fruit("peach", 300, 120, 60);
        fruit1.addInventory(5);
        System.out.println(fruit1.getQuantAvailable());
        System.out.println(fruit2.getQuantAvailable());
        System.out.println(fruit3.getQuantAvailable());

        System.out.println(fruit1.toString());
        System.out.println(fruit2.toString());
        System.out.println(fruit3.toString());
        fruit1.purchase(5);

        System.out.println(fruit1.toString());
        System.out.println("original Quantity");
        System.out.println(fruit1.toString());
        fruit1.refunded(5);
        System.out.println("sold Quantity");
        System.out.println(fruit1.toString());
        fruit1.refunded(5);
        System.out.println("refunded Quantity");
        System.out.println(Stand.fruitTypeArray.get(0).name);
        System.out.println(Stand.fruitTypeArray.get(0));


    }

}