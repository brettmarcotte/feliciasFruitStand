    package com.company;

    import java.text.NumberFormat;

    public class Product {

        private String name;
        private String productType;
        private int price;
        private int Available;
        private int Sold;

        public Product(String name, String prodType, int price, int Avail, int Sold){
            this.name = name;
            this.productType = prodType;
            this.price = price;
            this.Available = Avail;
            this.Sold = Sold;


        }

        public int getPrice() {

            return price/100;
        }

        public void addInventory(int inv){

            this.Available += inv;

        }

        public void purchase(int pur){

            this.Sold += pur;
            this.Available -= pur;

        }

            @Override
            public String toString() {

            String output = "";

            NumberFormat currency = NumberFormat.getCurrencyInstance();

                String quantAvail;
                return output += "Name of Product: " + name + "\nType or Product" + productType + "Price: " + currency.format(getPrice()) + "\nQuantity Available:" + Available + "\nQuantity Sold: " +
                Sold + "\n\n" ;

            }

    }
