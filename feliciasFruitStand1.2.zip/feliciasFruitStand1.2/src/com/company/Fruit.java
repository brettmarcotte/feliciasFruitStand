package com.company;

import java.util.Objects;

public class Fruit extends Product {

    private static String[] flavorTypes = {"Sweet","Sour", "Bitter","Nutty","Tangy"};
    private String flavor;
    private String color;


    public Fruit(String name, String prodType, String color, int flavIndex, int price, int Avail, int Sold) {
        super(name, prodType, price, Avail, Sold);
        this.color = color;
        this.flavor = flavorTypes[flavIndex];

    }


    void getFlavor(){
        System.out.println (flavor);
    }

    boolean checkColor(String clr){
        if(color == clr){
            return true;
        } else return false;
    }

}
