package com.company;

public class Main {

    public static void main(String[] args) {

        Fruit fruit1 = new Fruit("Fruit","Apple", "red", 1, 300,10,0 );
        Fruit fruit2 = new Fruit("Fruit","Orange", "orange", 1, 300,25,10 );
        Fruit fruit3 = new Fruit("Fruit","Banana", "yellow", 1, 300,15,5 );

        fruit1.getFlavor();

        Meat meat1 = new Meat("Steak", "Sirloin", 8, 0, 1000, 21, 18);
        Meat meat2 = new Meat("Steak", "Chicken Breast", 8, 0, 1000, 21, 18);
        Meat meat3 = new Meat("Steak", "Sirloin", 8, 0, 1000, 21, 18);
        meat1.getGrade();
        System.out.println(meat1.getPricePerPound());

        System.out.println();


    }
}
