    package com.company;

    import java.util.ArrayList;

    public class Stand {

        private int Count;
        private int sales;
        private Fruit[] totalInventory;
        private int Profit;
        static ArrayList<Product> inventory = new ArrayList<>();


        public void standProfit() {
            System.out.println("This stand turned a profit of " + Profit);
        }

        public void displayProduct() {
            if (inventory.isEmpty()) {
                System.out.println("Inventory is empty");
            } else if (inventory.size() == 1) {
                System.out.println("The stand has " + inventory.size() + "item is in inventory");
                System.out.println(inventory);
            }

        }

        public void totalInventory(int inv){ //counts up the total number of product in the stand
        for (int i = 0; i < inventory.size(); i++);
            System.out.println(inventory);
        }

    }
