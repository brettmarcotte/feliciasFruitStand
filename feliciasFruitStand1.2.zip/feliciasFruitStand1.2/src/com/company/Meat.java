package com.company;

public class Meat extends Product {

    private int weight;
    private static String[] meatGrade = {"Prime", "Choice", "Select"};
    private String grade;

    public Meat(String name, String prodType, int weight, int gIndex, int price, int Avail, int Sold) {
        super(name, prodType, price, Avail, Sold);
        this.weight = weight;
        this.grade = meatGrade[gIndex];

    }

    void getGrade() {
        System.out.println(grade);
    }

    int getPricePerPound(){

        int  pLbs = this.getPrice() * weight;

        return pLbs;
    }



}
